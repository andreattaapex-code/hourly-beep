import { AppService } from '@zos/app'
import { SystemSounds } from '@zos/sensor'
import { getSystemMode } from '@zos/settings'

AppService({
  onInit(options) {
    // This service is invoked both by the persistent hourly alarm and by
    // the Sleep Mode system event. Sleep events only wake this service;
    // they do not produce a sound.
    const isSystemEvent = options && String(options).indexOf('event=event:os.system.sleep_mode') >= 0
    if (isSystemEvent) return

    const mode = getSystemMode()
    if (mode && mode.sleep) return

    const systemSounds = new SystemSounds()
    if (systemSounds.getEnabled()) {
      const soundTypes = systemSounds.getSourceType()
      systemSounds.start(soundTypes.REGULAR, 0)
    }
  },
  onDestroy() {}
})
