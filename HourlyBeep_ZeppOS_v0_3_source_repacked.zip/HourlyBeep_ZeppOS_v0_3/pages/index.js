import { createWidget, widget, align } from '@zos/ui'
import { px } from '@zos/utils'
import { set, cancel, REPEAT_HOUR } from '@zos/alarm'
import { localStorage } from '@zos/storage'
import { showToast } from '@zos/interaction'

const KEY = 'hourly_beep_alarm_id'

Page({
  build() {
    createWidget(widget.TEXT, {
      x: px(10), y: px(45), w: px(460), h: px(55),
      text: 'HOURLY BEEP',
      text_size: px(28), align_h: align.CENTER_H
    })
    createWidget(widget.TEXT, {
      x: px(20), y: px(110), w: px(440), h: px(90),
      text: 'Beep cada hora en punto. Sin vibracion. Pausa en modo sueno.',
      text_size: px(18), align_h: align.CENTER_H
    })
    createWidget(widget.BUTTON, {
      x: px(55), y: px(235), w: px(370), h: px(65),
      text: 'ACTIVAR',
      click_func: () => {
        const oldId = Number(localStorage.getItem(KEY, '0'))
        if (oldId > 0) cancel(oldId)

        const now = Math.floor(Date.now() / 1000)
        const nextHour = (Math.floor(now / 3600) + 1) * 3600
        const id = set({
          url: 'app-service/hourly',
          time: nextHour,
          repeat_type: REPEAT_HOUR,
          store: true,
          param: 'hourly_beep'
        })
        if (id > 0) {
          localStorage.setItem(KEY, String(id))
          showToast({ content: 'Hourly Beep activado' })
        } else {
          showToast({ content: 'No se pudo crear la alarma' })
        }
      }
    })
    createWidget(widget.BUTTON, {
      x: px(55), y: px(320), w: px(370), h: px(65),
      text: 'DESACTIVAR',
      click_func: () => {
        const id = Number(localStorage.getItem(KEY, '0'))
        if (id > 0) cancel(id)
        localStorage.removeItem(KEY)
        showToast({ content: 'Hourly Beep desactivado' })
      }
    })
  }
})
