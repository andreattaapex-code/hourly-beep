# Hourly Beep v0.3 — Zepp OS source

## Implemented in source
- Persistent alarm set for the next full-hour boundary, repeating hourly (`REPEAT_HOUR`).
- Alarm wakes a single-execution App Service; no permanent background loop.
- The service checks Sleep Mode via `getSystemMode().sleep` before sound.
- The same App Service is registered for `event:os.system.sleep_mode`; the event invocation itself is silent.
- Uses the built-in `SystemSounds.REGULAR` sound once; no vibration API is called.
- Activate cancels an older stored alarm before creating a new one; Deactivate cancels the saved alarm.

## Not yet compiled or tested on an Active 2 Premium
This archive is source code, not a `.zab` installer. The build requires the official Zeus CLI, Node.js, a real developer `appId`, a valid icon asset, and the target device profile supported by the SDK.

## Build steps
1. Install Node.js (Zeus CLI documentation specifies Node.js 14+).
2. Install CLI: `npm i @zeppos/zeus-cli -g`
3. Create a Zepp OS v3+ Mini Program using `zeus create` and choose a compatible device target.
4. Copy `app.json`, `pages/index.js`, and `app-service/hourly.js` into the generated project; add a valid icon in `assets/icon.png`; set your real `appId`.
5. Run `zeus build`; the `.zab` output is generated in `dist/`.
6. Use `zeus preview` / Zepp App Developer Mode to install and test on the watch.

## Device tests required
- Activation: first sound at next full hour, then each hour.
- Deactivation: no later sound.
- Sleep Mode on at hour boundary: no sound.
- Exit Sleep Mode: sound resumes at next hour boundary.
- Sound setting enabled on watch.
The built-in REGULAR tone is documented as “TingTing”; it may not sound like a custom electronic beep. `SystemSounds` requires API_LEVEL 3.6. Confirm the target firmware supports this API.
